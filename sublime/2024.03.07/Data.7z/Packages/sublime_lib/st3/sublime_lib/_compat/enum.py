if False:  # For MyPy only
    from enum import *  # noqa: F401, F403
else:
    from ..vendor.python.enum import *  # type: ignore # noqa: F401, F403
